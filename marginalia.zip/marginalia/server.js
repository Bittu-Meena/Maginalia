import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { parseChapters } from './lib/chapters.js';
import { extractVideoId, loadVideo, sliceTranscript, condenseTranscript, parseTranscriptText, setManualTranscript } from './lib/youtube.js';
import { generate, listModels } from './lib/gemini.js';
import { notesSystem, notesPrompt, condenseSystem, condensePrompt, TOPICS_SYSTEM, topicsPrompt } from './lib/prompts.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Tiny .env loader (no extra dependency).
try {
  const env = fs.readFileSync(path.join(__dirname, '.env'), 'utf8');
  for (const line of env.split(/\r?\n/)) {
    if (line.trim().startsWith('#')) continue;
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/i);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
  }
} catch {
  /* no .env file: fine */
}

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '127.0.0.1';
const DEFAULT_MODEL = process.env.GEMINI_MODEL || 'gemini-flash-latest';

const app = express();
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Gemini sometimes wraps the whole answer in a ```markdown fence. Remove only that outer fence,
// never the closing fence of a diagram block at the end.
const stripOuterFence = (t) => {
  const m = String(t).match(/^```(?:markdown|md)\s*\n([\s\S]*?)\n```\s*$/i);
  return m ? m[1] : String(t);
};

const wrap = (fn) => (req, res, next) => fn(req, res).catch(next);
const bad = (message, status = 400, fatal = false) => Object.assign(new Error(message), { status, fatal });

function auth(body) {
  const apiKey = String(body.apiKey || process.env.GEMINI_API_KEY || '').trim();
  if (!apiKey) throw bad('Add your Gemini API key in Gemini settings first.', 400, true);
  const model = String(body.model || DEFAULT_MODEL).trim();
  return { apiKey, model };
}

app.get('/api/config', (req, res) => {
  res.json({ serverKey: Boolean(process.env.GEMINI_API_KEY), defaultModel: DEFAULT_MODEL });
});

// 1. Video link -> title, length, topics
app.post(
  '/api/video',
  wrap(async (req, res) => {
    const id = extractVideoId(req.body.url);
    if (!id) throw bad('That doesn’t look like a YouTube link. Paste something like https://youtu.be/VIDEO_ID');

    const video = await loadVideo(id, { refresh: Boolean(req.body.refresh) });
    const pasted = String(req.body.topicsText || '').trim();
    const chapters = parseChapters(pasted || video.description, video.duration);
    if (pasted && !chapters.length) {
      throw bad('Couldn’t find at least two timestamps in that text. Use one topic per line, like “05:32 Electromagnetic Induction”.');
    }

    res.json({
      videoId: id,
      title: video.title,
      author: video.author,
      duration: video.duration,
      hasTranscript: video.segments.length > 0,
      transcriptNote: video.segments.length ? '' : video.problems.join(' | '),
      topicsSource: pasted ? 'pasted' : chapters.length ? 'description' : 'none',
      chapters,
    });
  })
);

// 1a. Captions could not be downloaded: use a transcript the person copied from YouTube
app.post(
  '/api/transcript',
  wrap(async (req, res) => {
    const id = extractVideoId(req.body.videoId);
    if (!id) throw bad('Missing video.');
    const segments = parseTranscriptText(req.body.text);
    if (segments.length < 5) {
      throw bad('Couldn’t find timestamps in that text. Copy the transcript from YouTube’s “Show transcript” panel, with its times (like 0:05), and paste it again.');
    }
    await setManualTranscript(id, segments);
    res.json({ ok: true, lines: segments.length });
  })
);

// 1b. No topics in the description: ask Gemini to propose them from the captions
app.post(
  '/api/auto-topics',
  wrap(async (req, res) => {
    const id = extractVideoId(req.body.videoId);
    if (!id) throw bad('Missing video.');
    const { apiKey, model } = auth(req.body);
    const video = await loadVideo(id);
    if (!video.segments.length) throw bad('This video has no captions, so topics can’t be detected.');

    const { text } = await generate({
      apiKey,
      model,
      system: TOPICS_SYSTEM,
      prompt: topicsPrompt({ videoTitle: video.title, condensed: condenseTranscript(video.segments) }),
      json: true,
      maxOutputTokens: 4096,
    });

    let list;
    try {
      list = JSON.parse(text.replace(/^```(?:json)?\s*|\s*```$/g, ''));
    } catch {
      throw bad('Gemini’s topic list wasn’t readable. Try again.', 502);
    }
    const rows = (Array.isArray(list) ? list : [])
      .filter((t) => t && Number.isFinite(Number(t.start)) && t.title)
      .map((t) => ({ start: Math.max(0, Math.floor(Number(t.start))), title: String(t.title).trim() }))
      .sort((a, b) => a.start - b.start)
      .filter((c, i, a) => i === 0 || c.start !== a[i - 1].start);
    if (rows.length < 2) throw bad('Gemini didn’t find separate topics in this video.', 502);

    const chapters = rows.map((c, i) => ({
      id: i,
      title: c.title,
      start: c.start,
      end: i + 1 < rows.length ? rows[i + 1].start : video.duration > c.start ? video.duration : null,
    }));
    res.json({ chapters, topicsSource: 'gemini' });
  })
);

// 2. List the models this API key can use
app.post(
  '/api/models',
  wrap(async (req, res) => {
    const { apiKey } = auth(req.body);
    res.json({ models: await listModels(apiKey) });
  })
);

// 3. Notes for ONE topic (the browser calls this once per selected topic)
app.post(
  '/api/notes',
  wrap(async (req, res) => {
    const id = extractVideoId(req.body.videoId);
    if (!id) throw bad('Missing video.');
    const { apiKey, model } = auth(req.body);
    const t = req.body.topic || {};
    const topic = {
      title: String(t.title || 'Topic').slice(0, 200),
      start: Math.max(0, Number(t.start) || 0),
      end: t.end == null ? null : Number(t.end),
    };
    const o = req.body.options || {};

    const video = await loadVideo(id);
    if (!video.segments.length) {
      throw bad('This video has no captions, so notes can’t be made from it.');
    }
    const transcript = sliceTranscript(video.segments, topic.start, topic.end);
    if (transcript.length < 40) {
      throw bad(`No captions found for “${topic.title}”. It may be a silent part or a break.`);
    }

    const { text, finishReason } = await generate({
      apiKey,
      model,
      system: notesSystem({ detail: o.detail, language: o.language, practice: Boolean(o.practice), diagrams: Boolean(o.diagrams) }),
      prompt: notesPrompt({ videoTitle: video.title, topic, transcript }),
    });

    let markdown = stripOuterFence(text);
    if (finishReason === 'MAX_TOKENS') {
      markdown += '\n\n> **Note:** these notes were cut off because the topic is very long. Try “Concise” detail or Retry.';
    }
    res.json({ markdown });
  })
);

// 4. Shorter version of notes that already exist (tables + one formula sheet)
app.post(
  '/api/condense',
  wrap(async (req, res) => {
    const { apiKey, model } = auth(req.body);
    const markdown = String(req.body.markdown || '').slice(0, 200000);
    if (markdown.trim().length < 20) throw bad('There are no notes to shorten yet.');
    const title = String(req.body.title || 'Topic').slice(0, 200);
    const language = String(req.body.options?.language || 'english');

    const { text, finishReason } = await generate({
      apiKey,
      model,
      system: condenseSystem({ language }),
      prompt: condensePrompt({ title, markdown }),
    });
    let out = stripOuterFence(text);
    if (finishReason === 'MAX_TOKENS') out += '\n\n> **Note:** this short version was cut off. Press Make shorter again.';
    res.json({ markdown: out });
  })
);

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  const status = err.status >= 400 && err.status < 600 ? err.status : 500;
  if (status >= 500) console.error(err);
  res.status(status).json({ error: err.message || 'Something went wrong.', fatal: Boolean(err.fatal) });
});

app.listen(PORT, HOST, () => {
  console.log(`\n  Marginalia is running at http://${HOST === '127.0.0.1' ? 'localhost' : HOST}:${PORT}\n`);
});
