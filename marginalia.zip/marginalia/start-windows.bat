@echo off
cd /d "%~dp0"
title Marginalia

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed yet.
  echo Opening the download page. Install the LTS version, restart your computer, then double-click this file again.
  start https://nodejs.org
  pause
  exit /b
)

if not exist node_modules (
  echo First time setup. This takes about a minute, please wait...
  call npm install
  if errorlevel 1 (
    echo Setup failed. Check your internet connection and try again.
    pause
    exit /b
  )
)

echo.
echo Marginalia is starting. Your browser will open in a moment.
echo Keep this window open while you use the app. Close it to stop the app.
echo.
start "" /min cmd /c "timeout /t 3 /nobreak >nul && start http://localhost:3000"
node server.js
pause
