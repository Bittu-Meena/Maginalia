#!/bin/bash
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is not installed yet. Opening the download page."
  echo "Install the LTS version, then double-click this file again."
  open https://nodejs.org
  read -p "Press Enter to close"
  exit 1
fi
if [ ! -d node_modules ]; then
  echo "First time setup. This takes about a minute, please wait..."
  npm install || { echo "Setup failed. Check your internet connection."; read -p "Press Enter to close"; exit 1; }
fi
echo "Marginalia is starting. Keep this window open while you use the app."
(sleep 3 && open http://localhost:3000) &
node server.js
