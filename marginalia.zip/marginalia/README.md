# Marginalia

Paste a YouTube lecture link, tick any topics, and Gemini writes study notes from the captions of just those parts. Preview them, then download a PDF.

## Easiest way to run it

Install Node.js (the LTS version from https://nodejs.org), then **double-click `start-windows.bat`** (Windows) or **`start-mac.command`** (Mac; if it is blocked, right-click it and choose Open). The first time it sets itself up, then your browser opens the app. Keep the black window open while you use it.

## Run it by hand

You need [Node.js](https://nodejs.org) 20 or newer and a free Gemini API key from https://aistudio.google.com/apikey

```bash
npm install
npm start
```

Open http://localhost:3000

Then press **Gemini settings** (top right), paste your key, press **Load models**, choose a model and save.
Or skip that step: copy `.env.example` to `.env` and put the key there.

## How it works

1. **Get topics.** The server reads the video description and turns timestamp lines into topics. Formats like `05:32 Title`, `05:32 - Title`, `Title 05:32` and `[05:32](link) - Title` all work. No timestamps in the description? Paste them in, or press *Detect topics with Gemini*.
2. **Pick topics.** Any combination, e.g. Mutual Inductance + Self Inductance + Magnetic Flux.
3. **Make notes.** For each picked topic the server takes only the captions between that topic's start and the next topic's start, and asks Gemini for notes. The default *Short: tables and formulas* style gives one-line points, tables for parallel information, and a formula table for every topic. *Standard* and *Detailed* are there if you want more. Topics are done one at a time, so you see progress, and one failure does not lose the others.
4. **Preview and edit.** Formulas are shown with KaTeX. With *Draw diagrams and flowcharts* ticked, Gemini draws the figures a teacher would put on the board (circuits, coils with field lines, rods on rails, graphs) as SVG, and laws or processes as flowcharts. Each topic has an *Edit text* button (Markdown) and a *Regenerate* button if something looks wrong.
5. **Make shorter.** One click rewrites every topic as compact tables plus a single *Formula sheet* with every formula, with the explanations removed. Use the *Full | Short* switch to compare. Your full notes are kept.
6. **Set the text size.** The `A−` and `A+` buttons work like browser zoom (80% to 160%) and the PDF follows the size you choose.
7. **Download.** *Download PDF* saves an A4 PDF directly (always black on white, even in dark mode). *Print* then "Save as PDF" gives a PDF with selectable text.

The **sun/moon button** (top right) switches between light and dark mode. It follows your computer's setting until you change it.

## If something goes wrong

- **“Couldn’t download the captions automatically”.** Auto-generated YouTube captions are used when a video has no uploaded ones. The app tries four download routes. If YouTube blocks all of them, a box appears: open the video on YouTube, click *…more*, then *Show transcript*, click inside it, press Ctrl+A, Ctrl+C, and paste into the box. Run the app on your own computer, because YouTube often blocks cloud servers. Still failing? Open *Technical details* in that box. If it was broken by a YouTube change, run `npm update youtubei.js`.
- **“Couldn’t load this video”.** Check that the video is public and the link is right.
- **“Gemini can’t find this model”.** Google retires model names regularly. Open Gemini settings, press *Load models*, and choose one from the list.
- **Rate limit (429).** Free keys allow only a few requests per minute. Wait, then press *Retry* on the topic.
- **Hindi text looks wrong in the PDF.** Use *Print*, then “Save as PDF”.

## Files

```
server.js            web server and API routes
lib/chapters.js      timestamp parser
lib/youtube.js       video details and captions
lib/gemini.js        Gemini REST client, model list, retries
lib/prompts.js       the instructions given to Gemini
public/              the web page (index.html, style.css, app.js)
```

Your API key stays in your browser and is sent only to your own local server, which forwards it to Google.
